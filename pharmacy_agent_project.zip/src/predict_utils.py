
# sample module
def predict_example(model, X):
    """Return predictions from model"""
    return model.predict(X)
