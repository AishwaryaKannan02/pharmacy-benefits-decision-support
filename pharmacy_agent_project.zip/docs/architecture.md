
# Architecture - Blogger Agent + Prior Auth Predictor

See the ASCII diagram in the main notebook. The blogger_agent analyzes the codebase,
uses a planner to create an outline, writer to draft content, editor to polish,
and social_media_writer to create snippets. Validators check outline and final post.
